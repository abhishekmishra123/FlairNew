package Common;

public interface TimeOuts {
	
	public static final int VERYSHORTWAIT = 5;
	public static final int SHORTWAIT = 15;
	public static final int MEDIUMWAIT = 30;
	public static final int LONGWAIT = 55;
	public static final int VERYLONGWAIT = 90;
	public static final int IMPLICITWAIT = 10;

}
